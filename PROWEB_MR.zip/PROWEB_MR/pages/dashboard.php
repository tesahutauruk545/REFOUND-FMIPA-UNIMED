<?php

session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Dashboard - PROWEB MR</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>

        body {
            margin: 0;
            background: #f7f7fb;
        }

        .dashboard {
            min-height: 100vh;
            padding: 50px 20px;
        }

        .dashboard-container {
            max-width: 1000px;
            margin: auto;
        }

        .welcome {
            background: white;
            padding: 30px;
            border-radius: 18px;
            margin-bottom: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        }

        .welcome p {
            color: #777;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .dashboard-card {
            background: white;
            padding: 25px;
            border-radius: 16px;
            text-decoration: none;
            color: #222;
            box-shadow: 0 10px 30px rgba(0,0,0,0.06);
            transition: 0.2s;
        }

        .dashboard-card:hover {
            transform: translateY(-3px);
        }

        .dashboard-card span {
            font-size: 35px;
        }

        .dashboard-card h3 {
            margin: 15px 0 8px;
        }

        .dashboard-card p {
            color: #777;
        }

        .logout {
            display: inline-block;
            margin-top: 25px;
            color: #c0392b;
            text-decoration: none;
        }

        @media (max-width: 700px) {

            .dashboard-grid {
                grid-template-columns: 1fr;
            }

        }

    </style>

</head>

<body>

<div class="dashboard">

    <div class="dashboard-container">

        <div class="welcome">

            <h1>
                Selamat datang,
                <?= htmlspecialchars($_SESSION["user_name"]) ?>!
            </h1>

            <p>
                Kelola laporan barang hilang dan barang ditemukan
                melalui PROWEB MR.
            </p>

        </div>


        <div class="dashboard-grid">


            <a href="lost.php" class="dashboard-card">

                <span>🔍</span>

                <h3>Barang Hilang</h3>

                <p>
                    Laporkan barang yang kamu kehilangan.
                </p>

            </a>


            <a href="found.php" class="dashboard-card">

                <span>📦</span>

                <h3>Barang Ditemukan</h3>

                <p>
                    Laporkan barang yang kamu temukan.
                </p>

            </a>


            <a href="matches.php" class="dashboard-card">

                <span>🤝</span>

                <h3>Automatic Matching</h3>

                <p>
                    Lihat kemungkinan kecocokan barang.
                </p>

            </a>


        </div>


        <a href="logout.php" class="logout">
            Keluar dari akun
        </a>

    </div>

</div>

</body>

</html>