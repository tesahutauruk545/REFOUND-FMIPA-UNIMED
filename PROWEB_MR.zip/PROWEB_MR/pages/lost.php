<?php

session_start();

require_once "../config/database.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

$message = "";
$messageType = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $item_name = trim($_POST["item_name"]);
    $category = trim($_POST["category"]);
    $brand = trim($_POST["brand"]);
    $color = trim($_POST["color"]);
    $description = trim($_POST["description"]);
    $lost_location = trim($_POST["lost_location"]);
    $lost_date = $_POST["lost_date"];

    $imageName = "";

    if (
        empty($item_name) ||
        empty($category) ||
        empty($description) ||
        empty($lost_location) ||
        empty($lost_date)
    ) {

        $message = "Data wajib diisi dengan lengkap.";
        $messageType = "error";

    } else {

        /* UPLOAD FOTO */

        if (isset($_FILES["image"]) && $_FILES["image"]["error"] !== UPLOAD_ERR_NO_FILE) {

            if ($_FILES["image"]["error"] !== UPLOAD_ERR_OK) {

                $message = "Foto gagal diupload.";
                $messageType = "error";

            } elseif ($_FILES["image"]["size"] > 2 * 1024 * 1024) {

                $message = "Ukuran foto maksimal 2 MB.";
                $messageType = "error";

            } else {

                $allowedTypes = [
                    "image/jpeg",
                    "image/png",
                    "image/webp"
                ];

                $fileInfo = finfo_open(FILEINFO_MIME_TYPE);
                $mimeType = finfo_file($fileInfo, $_FILES["image"]["tmp_name"]);
                finfo_close($fileInfo);

                if (!in_array($mimeType, $allowedTypes)) {

                    $message = "Format foto harus JPG, PNG, atau WEBP.";
                    $messageType = "error";

                } else {

                    $extension = pathinfo(
                        $_FILES["image"]["name"],
                        PATHINFO_EXTENSION
                    );

                    $imageName = "lost_" . uniqid() . "." . strtolower($extension);

                    $uploadPath = "../uploads/" . $imageName;

                    if (!move_uploaded_file(
                        $_FILES["image"]["tmp_name"],
                        $uploadPath
                    )) {

                        $message = "Foto gagal disimpan.";
                        $messageType = "error";

                        $imageName = "";
                    }
                }
            }
        }


        if (empty($message)) {

            $stmt = $conn->prepare(
                "INSERT INTO lost_items
                (user_id, item_name, category, brand, color, description, lost_location, lost_date, image)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );

            $stmt->bind_param(
                "issssssss",
                $_SESSION["user_id"],
                $item_name,
                $category,
                $brand,
                $color,
                $description,
                $lost_location,
                $lost_date,
                $imageName
            );

            if ($stmt->execute()) {

                $message = "Laporan barang hilang berhasil disimpan.";
                $messageType = "success";

            } else {

                $message = "Terjadi kesalahan saat menyimpan data.";
                $messageType = "error";
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Lapor Barang Hilang - PROWEB MR</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>

        body {
            margin: 0;
            background: #f7f7fb;
        }

        .report-container {
            min-height: 100vh;
            padding: 50px 20px;
        }

        .report-card {
            max-width: 650px;
            margin: auto;
            background: white;
            padding: 35px;
            border-radius: 18px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.08);
        }

        .report-card h1 {
            margin-bottom: 10px;
        }

        .report-card > p {
            color: #777;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 7px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 13px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-sizing: border-box;
        }

        .form-group textarea {
            min-height: 120px;
            resize: vertical;
        }

        .submit-button {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 8px;
            background: #6c63ff;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        .message {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .success {
            background: #eefbf2;
            color: #287a42;
        }

        .error {
            background: #fff0f0;
            color: #c0392b;
        }

        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #6c63ff;
            text-decoration: none;
        }

        .upload-note {
            font-size: 13px;
            color: #777;
            margin-top: 6px;
        }

    </style>

</head>

<body>

<div class="report-container">

    <div class="report-card">

        <a href="dashboard.php" class="back-link">
            ← Kembali ke Dashboard
        </a>

        <h1>Lapor Barang Hilang</h1>

        <p>
            Isi informasi barang yang kamu kehilangan.
        </p>


        <?php if (!empty($message)): ?>

            <div class="message <?= $messageType ?>">
                <?= htmlspecialchars($message) ?>
            </div>

        <?php endif; ?>


        <form method="POST" enctype="multipart/form-data">

            <div class="form-group">

                <label>Nama Barang</label>

                <input
                    type="text"
                    name="item_name"
                    placeholder="Contoh: Laptop ASUS"
                    required
                >

            </div>


            <div class="form-group">

                <label>Kategori</label>

                <select name="category" required>

                    <option value="">Pilih kategori</option>

                    <option value="Elektronik">Elektronik</option>
                    <option value="Dokumen">Dokumen</option>
                    <option value="Aksesoris">Aksesoris</option>
                    <option value="Pakaian">Pakaian</option>
                    <option value="Tas">Tas</option>
                    <option value="Lainnya">Lainnya</option>

                </select>

            </div>


            <div class="form-group">

                <label>Brand</label>

                <input
                    type="text"
                    name="brand"
                    placeholder="Contoh: ASUS"
                >

            </div>


            <div class="form-group">

                <label>Warna</label>

                <input
                    type="text"
                    name="color"
                    placeholder="Contoh: Hitam"
                >

            </div>


            <div class="form-group">

                <label>Deskripsi / Ciri Khusus</label>

                <textarea
                    name="description"
                    placeholder="Contoh: Ada stiker putih kecil di bagian kanan."
                    required
                ></textarea>

            </div>


            <div class="form-group">

                <label>Lokasi Kehilangan</label>

                <input
                    type="text"
                    name="lost_location"
                    placeholder="Contoh: Gedung FMIPA lantai 2"
                    required
                >

            </div>


            <div class="form-group">

                <label>Tanggal Kehilangan</label>

                <input
                    type="date"
                    name="lost_date"
                    required
                >

            </div>


            <div class="form-group">

                <label>Foto Barang</label>

                <input
                    type="file"
                    name="image"
                    accept="image/jpeg,image/png,image/webp"
                >

                <div class="upload-note">
                    Opsional. Maksimal 2 MB. JPG, PNG, atau WEBP.
                </div>

            </div>


            <button
                type="submit"
                class="submit-button">

                Kirim Laporan

            </button>

        </form>

    </div>

</div>

</body>

</html>