<?php

require_once "../config/database.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    if (empty($name) || empty($email) || empty($password)) {
        $message = "Semua field wajib diisi.";
    } else {

        // Cek apakah email sudah digunakan
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {

            $message = "Email sudah terdaftar.";

        } else {

            // Enkripsi password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $conn->prepare(
                "INSERT INTO users (name, email, password) VALUES (?, ?, ?)"
            );

            $stmt->bind_param(
                "sss",
                $name,
                $email,
                $hashed_password
            );

            if ($stmt->execute()) {

                header("Location: login.php?registered=1");
                exit;

            } else {

                $message = "Pendaftaran gagal.";

            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Daftar - PROWEB MR</title>

    <link rel="stylesheet"
          href="../css/style.css">

    <style>

        .auth-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 30px;
        }

        .auth-card {
            width: 100%;
            max-width: 420px;
            background: white;
            padding: 40px;
            border-radius: 18px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.08);
        }

        .auth-card h1 {
            margin-bottom: 10px;
        }

        .auth-card > p {
            color: #777;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 7px;
        }

        .form-group input {
            width: 100%;
            padding: 13px;
            border: 1px solid #ddd;
            border-radius: 8px;
            outline: none;
        }

        .form-group input:focus {
            border-color: #6c63ff;
        }

        .auth-button {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 8px;
            background: #6c63ff;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        .message {
            margin-bottom: 20px;
            padding: 12px;
            border-radius: 8px;
            background: #fff0f0;
            color: #c0392b;
            font-size: 14px;
        }

        .auth-link {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
        }

        .auth-link a {
            color: #6c63ff;
            text-decoration: none;
            font-weight: bold;
        }

    </style>

</head>

<body>

<div class="auth-container">

    <div class="auth-card">

        <h1>Buat Akun</h1>

        <p>
            Daftar untuk menggunakan PROWEB MR.
        </p>

        <?php if (!empty($message)): ?>

            <div class="message">
                <?= htmlspecialchars($message) ?>
            </div>

        <?php endif; ?>


        <form method="POST">

            <div class="form-group">

                <label>Nama Lengkap</label>

                <input
                    type="text"
                    name="name"
                    placeholder="Masukkan nama lengkap"
                    required
                >

            </div>


            <div class="form-group">

                <label>Email</label>

                <input
                    type="email"
                    name="email"
                    placeholder="Masukkan email"
                    required
                >

            </div>


            <div class="form-group">

                <label>Password</label>

                <input
                    type="password"
                    name="password"
                    placeholder="Buat password"
                    required
                >

            </div>


            <button
                type="submit"
                class="auth-button">

                Daftar

            </button>

        </form>


        <div class="auth-link">

            Sudah punya akun?

            <a href="login.php">
                Masuk
            </a>

        </div>

    </div>

</div>

</body>

</html>