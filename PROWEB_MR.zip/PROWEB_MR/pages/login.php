<?php

session_start();

require_once "../config/database.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    if (empty($email) || empty($password)) {

        $message = "Email dan password wajib diisi.";

    } else {

        $stmt = $conn->prepare(
            "SELECT id, name, email, password
             FROM users
             WHERE email = ?"
        );

        $stmt->bind_param("s", $email);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows === 1) {

            $user = $result->fetch_assoc();

            if (password_verify($password, $user["password"])) {

                $_SESSION["user_id"] = $user["id"];
                $_SESSION["user_name"] = $user["name"];
                $_SESSION["user_email"] = $user["email"];

                header("Location: dashboard.php");
                exit;

            } else {

                $message = "Email atau password salah.";

            }

        } else {

            $message = "Email atau password salah.";

        }
    }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Masuk - PROWEB MR</title>

    <link rel="stylesheet"
          href="../css/style.css">

    <style>

        .auth-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 30px;
        }

        .auth-card {
            width: 100%;
            max-width: 420px;
            background: white;
            padding: 40px;
            border-radius: 18px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.08);
        }

        .auth-card h1 {
            margin-bottom: 10px;
        }

        .auth-card > p {
            color: #777;
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 7px;
        }

        .form-group input {
            width: 100%;
            padding: 13px;
            border: 1px solid #ddd;
            border-radius: 8px;
            outline: none;
        }

        .form-group input:focus {
            border-color: #6c63ff;
        }

        .auth-button {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 8px;
            background: #6c63ff;
            color: white;
            font-weight: bold;
            cursor: pointer;
        }

        .message {
            margin-bottom: 20px;
            padding: 12px;
            border-radius: 8px;
            background: #fff0f0;
            color: #c0392b;
            font-size: 14px;
        }

        .success {
            background: #eefbf2;
            color: #287a42;
        }

        .auth-link {
            margin-top: 20px;
            text-align: center;
            font-size: 14px;
        }

        .auth-link a {
            color: #6c63ff;
            text-decoration: none;
            font-weight: bold;
        }

    </style>

</head>

<body>

<div class="auth-container">

    <div class="auth-card">

        <h1>Selamat Datang</h1>

        <p>
            Masuk ke akun PROWEB MR.
        </p>


        <?php if (isset($_GET["registered"])): ?>

            <div class="message success">
                Pendaftaran berhasil. Silakan masuk.
            </div>

        <?php endif; ?>


        <?php if (!empty($message)): ?>

            <div class="message">
                <?= htmlspecialchars($message) ?>
            </div>

        <?php endif; ?>


        <form method="POST">

            <div class="form-group">

                <label>Email</label>

                <input
                    type="email"
                    name="email"
                    placeholder="Masukkan email"
                    required
                >

            </div>


            <div class="form-group">

                <label>Password</label>

                <input
                    type="password"
                    name="password"
                    placeholder="Masukkan password"
                    required
                >

            </div>


            <button
                type="submit"
                class="auth-button">

                Masuk

            </button>

        </form>


        <div class="auth-link">

            Belum punya akun?

            <a href="register.php">
                Daftar
            </a>

        </div>

    </div>

</div>

</body>

</html>