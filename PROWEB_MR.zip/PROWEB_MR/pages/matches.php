<?php

session_start();

require_once "../config/database.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}


function similarity($a, $b)
{
    $a = strtolower(trim($a ?? ""));
    $b = strtolower(trim($b ?? ""));

    if ($a === "" || $b === "") {
        return 0;
    }

    if ($a === $b) {
        return 100;
    }

    if (strpos($a, $b) !== false || strpos($b, $a) !== false) {
        return 80;
    }

    similar_text($a, $b, $percent);

    return $percent;
}


function calculateScore($lost, $found)
{
    $category = similarity(
        $lost["category"],
        $found["category"]
    );

    $color = similarity(
        $lost["color"],
        $found["color"]
    );

    $brand = similarity(
        $lost["brand"],
        $found["brand"]
    );

    $description = similarity(
        $lost["description"],
        $found["description"]
    );

    $location = similarity(
        $lost["lost_location"],
        $found["found_location"]
    );

    $name = similarity(
        $lost["item_name"],
        $found["item_name"]
    );


    $dateScore = 0;

    if (!empty($lost["lost_date"]) && !empty($found["found_date"])) {

        $lostDate = new DateTime($lost["lost_date"]);
        $foundDate = new DateTime($found["found_date"]);

        $difference = abs(
            $lostDate->diff($foundDate)->days
        );

        if ($difference == 0) {
            $dateScore = 100;
        } elseif ($difference <= 2) {
            $dateScore = 80;
        } elseif ($difference <= 7) {
            $dateScore = 50;
        }
    }


    return round(
        ($category * 0.20) +
        ($color * 0.15) +
        ($brand * 0.15) +
        ($description * 0.25) +
        ($location * 0.10) +
        ($dateScore * 0.10) +
        ($name * 0.05),
        2
    );
}


/*
    Hanya barang hilang milik user yang sedang login
    yang ditampilkan sebagai laporan pribadi.
*/

$userId = $_SESSION["user_id"];

$stmt = $conn->prepare(
    "SELECT *
     FROM lost_items
     WHERE user_id = ?
     AND status = 'active'
     ORDER BY created_at DESC"
);

$stmt->bind_param("i", $userId);
$stmt->execute();

$lostResult = $stmt->get_result();


$foundResult = $conn->query(
    "SELECT *
     FROM found_items
     WHERE status = 'active'
     ORDER BY created_at DESC"
);


$matches = [];


while ($lost = $lostResult->fetch_assoc()) {

    $foundResult->data_seek(0);

    while ($found = $foundResult->fetch_assoc()) {

        /*
            Jangan mencocokkan laporan dengan
            barang temuan milik user yang sama.
        */

        if ($lost["user_id"] == $found["user_id"]) {
            continue;
        }


        $score = calculateScore($lost, $found);


        if ($score >= 40) {

            $matches[] = [
                "lost" => $lost,
                "found" => $found,
                "score" => $score
            ];
        }
    }
}


usort($matches, function ($a, $b) {

    return $b["score"] <=> $a["score"];

});

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Automatic Matching - PROWEB MR</title>

    <link rel="stylesheet" href="../css/style.css">

    <style>

        body {
            margin: 0;
            background: #f7f7fb;
        }

        .match-container {
            min-height: 100vh;
            padding: 50px 20px;
        }

        .match-wrapper {
            max-width: 1000px;
            margin: auto;
        }

        .back-link {
            color: #6c63ff;
            text-decoration: none;
        }

        .match-header {
            margin: 25px 0;
        }

        .match-header p {
            color: #777;
        }

        .match-card {
            background: white;
            padding: 25px;
            margin-bottom: 20px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.07);
        }

        .match-items {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .item-box {
            padding: 20px;
            background: #f8f8fc;
            border-radius: 12px;
        }

        .item-box h3 {
            margin-top: 0;
        }

        .item-box p {
            margin: 8px 0;
        }

        .score {
            margin-top: 20px;
            padding: 18px;
            background: #eefbf2;
            border-radius: 10px;
            text-align: center;
        }

        .score strong {
            font-size: 30px;
        }

        .privacy-note {
            margin-top: 15px;
            padding: 12px;
            background: #fff8e6;
            border-radius: 8px;
            font-size: 13px;
            color: #7a5d00;
        }

        .empty {
            background: white;
            padding: 35px;
            border-radius: 15px;
            text-align: center;
        }

        @media (max-width: 700px) {

            .match-items {
                grid-template-columns: 1fr;
            }

        }

    </style>

</head>

<body>

<div class="match-container">

    <div class="match-wrapper">

        <a href="dashboard.php" class="back-link">
            ← Kembali ke Dashboard
        </a>


        <div class="match-header">

            <h1>Automatic Matching</h1>

            <p>
                Sistem membandingkan karakteristik laporan
                barang hilang dengan barang yang ditemukan.
            </p>

        </div>


        <?php if (empty($matches)): ?>

            <div class="empty">

                <h3>Belum ada kecocokan</h3>

                <p>
                    Sistem belum menemukan kemungkinan kecocokan.
                </p>

            </div>

        <?php else: ?>


            <?php foreach ($matches as $match): ?>

                <div class="match-card">

                    <div class="match-items">


                        <div class="item-box">

                            <h3>Barang Kamu</h3>

                            <p>
                                <strong>Nama:</strong>
                                <?= htmlspecialchars($match["lost"]["item_name"]) ?>
                            </p>

                            <p>
                                <strong>Kategori:</strong>
                                <?= htmlspecialchars($match["lost"]["category"]) ?>
                            </p>

                            <p>
                                <strong>Brand:</strong>
                                <?= htmlspecialchars($match["lost"]["brand"]) ?>
                            </p>

                            <p>
                                <strong>Warna:</strong>
                                <?= htmlspecialchars($match["lost"]["color"]) ?>
                            </p>

                            <p>
                                <strong>Lokasi:</strong>
                                <?= htmlspecialchars($match["lost"]["lost_location"]) ?>
                            </p>

                        </div>


                        <div class="item-box">

                            <h3>Barang Ditemukan</h3>

                            <p>
                                <strong>Kategori:</strong>
                                <?= htmlspecialchars($match["found"]["category"]) ?>
                            </p>

                            <p>
                                <strong>Warna:</strong>
                                <?= htmlspecialchars($match["found"]["color"]) ?>
                            </p>

                            <p>
                                <strong>Lokasi:</strong>
                                <?= htmlspecialchars($match["found"]["found_location"]) ?>
                            </p>

                            <p>
                                <strong>Tanggal:</strong>
                                <?= htmlspecialchars($match["found"]["found_date"]) ?>
                            </p>

                            <div class="privacy-note">

                                🔒 Foto dan ciri khusus barang temuan
                                disembunyikan untuk mencegah klaim
                                sepihak. Informasi tersebut digunakan
                                untuk proses verifikasi.

                            </div>

                        </div>

                    </div>


                    <div class="score">

                        <span>Match Score</span>

                        <br>

                        <strong>
                            <?= $match["score"] ?>%
                        </strong>

                        <br>

                        Kemungkinan kecocokan berdasarkan
                        karakteristik laporan.

                    </div>

                </div>

            <?php endforeach; ?>


        <?php endif; ?>

    </div>

</div>

</body>

</html>