<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0, viewport-fit=cover"
    >

    <meta
        name="description"
        content="RE:FOUND FMIPA UNIMED - Sistem Lost & Found untuk lingkungan FMIPA Universitas Negeri Medan."
    >

    <title>RE:FOUND — FMIPA UNIMED</title>

    <link rel="stylesheet" href="css/style.css">

</head>


<body>


<!-- =========================
     NAVBAR
========================= -->

<header class="navbar">

    <a
        href="index.php"
        class="brand-logo"
    >

        <img
            src="assets/refound-logo.png"
            alt="RE:FOUND FMIPA UNIMED"
        >

    </a>


    <nav>

        <a
            href="index.php"
            class="active"
        >
            Beranda
        </a>

        <a href="#cara-kerja">
            Cara Kerja
        </a>

        <a href="#tentang">
            Tentang
        </a>

    </nav>


    <div class="nav-buttons">

        <a
            href="pages/login.php"
            class="login-btn"
        >
            Masuk
        </a>

        <a
            href="pages/register.php"
            class="register-btn"
        >
            Daftar
        </a>

    </div>

</header>



<!-- =========================
     MAIN
========================= -->

<main>


<!-- HERO -->

<section class="hero">


    <div class="hero-content">


        <div class="hero-label">

            LOST & FOUND — FMIPA UNIMED

        </div>



        <h1>

            Kehilangan sesuatu?

            <br>

            <span>Let's re:find it.</span>

        </h1>



        <p class="hero-description">

            RE:FOUND membantu mahasiswa FMIPA UNIMED
            melaporkan barang hilang dan barang ditemukan
            dalam satu sistem yang lebih terarah dan aman.

        </p>



        <div class="hero-buttons">


            <a
                href="pages/lost.php"
                class="primary-btn"
            >

                🔎 Saya Kehilangan Barang

            </a>



            <a
                href="pages/found.php"
                class="secondary-btn"
            >

                📦 Saya Menemukan Barang

            </a>


        </div>


    </div>



    <!-- HERO VISUAL -->

    <div class="hero-visual">

        <div class="glass-orb"></div>


        <div class="visual-card">


            <div class="visual-icon">

                🔍

            </div>



            <h3>

                Barangmu mungkin
                sudah ditemukan.

            </h3>



            <p>

                RE:FOUND membandingkan karakteristik
                barang hilang dan barang ditemukan
                untuk mencari kemungkinan kecocokan.

            </p>



            <div class="match-preview">


                <div>

                    <span>
                        Match Score
                    </span>

                    <strong>
                        92%
                    </strong>

                </div>


                <div class="match-status">

                    Kemungkinan Cocok

                </div>


            </div>


        </div>

    </div>


</section>



<!-- =========================
     STEP
========================= -->

<section class="stats-section">


    <div class="stat-item">

        <strong>
            01
        </strong>

        <span>
            Laporkan Barang
        </span>

    </div>



    <div class="stat-item">

        <strong>
            02
        </strong>

        <span>
            Sistem Mencocokkan
        </span>

    </div>



    <div class="stat-item">

        <strong>
            03
        </strong>

        <span>
            Verifikasi & Temukan
        </span>

    </div>


</section>



<!-- =========================
     CARA KERJA
========================= -->

<section
    class="features"
    id="cara-kerja"
>


    <div class="section-heading">

        <p>
            CARA KERJA
        </p>


        <h2>

            Sederhana untuk digunakan.
            Lebih terarah untuk mencari.

        </h2>

    </div>



    <div class="feature-container">


        <div class="feature-card">


            <div class="feature-icon">

                📝

            </div>


            <h3>
                Laporkan
            </h3>


            <p>

                Masukkan informasi barang
                yang hilang atau barang
                yang kamu temukan.

            </p>


        </div>



        <div class="feature-card">


            <div class="feature-icon">

                🔗

            </div>


            <h3>
                Sistem Mencocokkan
            </h3>


            <p>

                Sistem membandingkan karakteristik
                barang untuk menemukan kemungkinan
                kecocokan.

            </p>


        </div>



        <div class="feature-card">


            <div class="feature-icon">

                🔐

            </div>


            <h3>
                Verifikasi
            </h3>


            <p>

                Informasi tertentu pada barang
                temuan tetap disembunyikan untuk
                membantu mencegah klaim sepihak.

            </p>


        </div>


    </div>


</section>



<!-- =========================
     TENTANG
========================= -->

<section
    class="features"
    id="tentang"
>


    <div class="section-heading">

        <p>
            TENTANG RE:FOUND
        </p>


        <h2>

            Lost & Found yang dibuat
            khusus untuk lingkungan
            FMIPA UNIMED.

        </h2>

    </div>



    <div class="feature-container">


        <div class="feature-card">


            <div class="feature-icon">
                🎓
            </div>


            <h3>
                Khusus FMIPA
            </h3>


            <p>

                Lingkup sistem difokuskan
                pada lingkungan FMIPA
                Universitas Negeri Medan.

            </p>


        </div>



        <div class="feature-card">


            <div class="feature-icon">
                ⚡
            </div>


            <h3>
                Lebih Terarah
            </h3>


            <p>

                Laporan barang tersimpan
                secara terstruktur sehingga
                lebih mudah dibandingkan
                pencarian manual.

            </p>


        </div>



        <div class="feature-card">


            <div class="feature-icon">
                🛡️
            </div>


            <h3>
                Lebih Aman
            </h3>


            <p>

                Detail tertentu dari barang
                temuan tidak langsung
                ditampilkan kepada pelapor.

            </p>


        </div>


    </div>


</section>


</main>



<!-- =========================
     FOOTER
========================= -->

<footer>


    <div class="footer-logo">

        <img
            src="assets/refound-logo.png"
            alt="RE:FOUND"
        >

    </div>


    <p>

        Lost & Found System —
        FMIPA Universitas Negeri Medan

    </p>


    <p class="copyright">

        © 2026 RE:FOUND FMIPA UNIMED

    </p>


</footer>



<script src="js/app.js"></script>

</body>

</html>